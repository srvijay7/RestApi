package com.api.rest.api.helper;

import java.net.URI;
import java.net.URISyntaxException;

import org.junit.Test;

public class TestGetMethod {
	@Test
	public void testCode() throws URISyntaxException
	{
		URI uri = new URI("localhost");
		String str = uri.getHost();
		int len = str.length();
		System.out.println(len);
		
		int len2 = new URI("localhost").getHost().length();
	}

}
