package com.api.rest.api.restassuredhelper;

import java.util.HashMap;
import java.util.Map;

import io.restassured.http.Headers;

import org.junit.BeforeClass;

import static io.restassured.RestAssured.*;
public class BaseClass {

	static Map<String, String> headers =new HashMap<String, String>();
	@BeforeClass
	public static void setUp()
	{
		baseURI = "http://localhost";
		port = 8080;
		basePath = "/laptop-bag/webapi/api";
	}
	
	public static void getHeaders()
	{
		headers.put("Accept", "application/json");
		headers.put("Content-Type", "application/json");
	}
}
