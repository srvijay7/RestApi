package com.api.rest.api.restassuredhelper;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/*import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString*/
@XmlRootElement(name="Laptop")
public class Laptopbag {
	private String brandName;
	private String Id;
	private String laptopName;
	private Features Feature;
	@XmlElement(name="BrandName")
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	@XmlElement(name="Id")
	public String getId() {
		return Id;
	}
	public void setId(String id) {
		Id = id;
	}
	@XmlElement(name="LaptopName")
	public String getLaptopName() {
		return laptopName;
	}
	public void setLaptopName(String laptopName) {
		this.laptopName = laptopName;
	}
	@XmlElement(name="Features")
	public Features getFeature() {
		return Feature;
	}
	public void setFeature(Features feature) {
		Feature = feature;
	}
	
	
	
	
	/*public Laptopbag(String brandName,String Id,String laptopName,Features Feature)
	{
		this.brandName = brandName;
		this.Id = Id;
		this.laptopName = laptopName;
		this.Feature = Feature;
	}*/

}
