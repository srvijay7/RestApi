package com.api.rest.api.restassuredhelper;

//import static io.restassured.RestAssured.*;

import static io.restassured.RestAssured.*;

import java.net.URI;
import java.net.URISyntaxException;
import lombok.*;

import org.junit.Test;

public class TestGet {

	@Test
	public void testGet() throws URISyntaxException
	{
		//URI uri = new URI("http://localhost:8080/laptop-bag/webapi/api/ping/hello");
		
		URI uri = new URI("http://localhost:8080/laptop-bag/webapi/api/ping/hello");
		String str = uri.getHost();
		int len = str.length();
		//RestAssured.when().get(uri);
		
		len=new URI("http://localhost:8080/laptop-bag/webapi/api/ping/hello").getHost().length();
		//when().get("http://localhost:8080/laptop-bag/webapi/api/ping/hello");
;	}
}
