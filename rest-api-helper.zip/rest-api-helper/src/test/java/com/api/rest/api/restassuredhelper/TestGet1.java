package com.api.rest.api.restassuredhelper;

import static io.restassured.RestAssured.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import junit.framework.Assert;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import org.apache.http.HttpStatus;
import org.apache.http.params.CoreConnectionPNames;
import org.junit.Test;

import static org.hamcrest.Matchers.*;
public class TestGet1 extends BaseClass{

	
	@Test
	public void testGet()
	{
		//Response response=when().get("http://localhost:8080/laptop-bag/webapi/api/all");
		//System.out.println(response.asString());
		System.out.println(given().accept(ContentType.JSON).when().get("http://localhost:8080/laptop-bag/webapi/api/all").asString());
		//System.out.println(given().accept(ContentType.JSON).when().get("https://jsonplaceholder.typicode.com/todos/1").asString());
	}
	
	
	@Test
	public void testStatusCode()
	{
		System.out.println(baseURI+port+basePath);
		int stausCode = given().accept(ContentType.JSON).when().get("http://localhost:8080/laptop-bag/webapi/api/all").thenReturn().getStatusCode();
		//int stausCode = given().accept(ContentType.JSON).when().get("/all").thenReturn().getStatusCode();
		System.out.println(stausCode);
		Assert.assertEquals(HttpStatus.SC_OK, stausCode);
		given().accept(ContentType.JSON).when().get("http://localhost:8080/laptop-bag/webapi/api/all").then().assertThat().statusCode(HttpStatus.SC_OK);
		//given().accept(ContentType.JSON).when().get("https://jsonplaceholder.typicode.com/todos/1").then().assertThat().statusCode(HttpStatus.SC_OK);
	}
	
	@Test
	public void testGetWithId()
	{
		given().accept(ContentType.JSON).when().get("/find/128").then().assertThat().statusCode(HttpStatus.SC_OK);
		String response=given().accept(ContentType.JSON).when().get("/find/128").thenReturn().body().asString();
		System.out.println(response);
	}
	@Test
	public void testGetWithNonId()
	{
		given().accept(ContentType.JSON).when().get("/find/222").then().assertThat().statusCode(HttpStatus.SC_NOT_FOUND);
	}
	@Test
	public void customHeaders()
	{
		given().headers(BaseClass.headers).when().get("/find/128").then().assertThat().statusCode(HttpStatus.SC_OK);
	}
	@Test
	public void validateResponse()
	{
		given().accept(ContentType.JSON).when().get("/find/128").then().body("BrandName", equalToIgnoringCase("Lenovo"),"Id",equalTo(128));
	}
	@Test
	public void listItem()
	{
		given().accept(ContentType.JSON).when().get("/find/128").then().body("Features.Feature",hasItem("8GB RAM"));
	}
	@Test
	public void listOfItems()
	{
		given().accept(ContentType.JSON).when().get("/find/128").then().body("Features.Feature",hasItems("8GB RAM","1TB Hard Drive","256 HDD"));
		given().accept(ContentType.JSON).when().get("/find/128").then().body("Features.Feature",hasSize(3));
		
	}
	@Test
	public void listCollect()
	{
		Response response = given().accept(ContentType.JSON).when().get("/all");
		List<Object> li = response.jsonPath().getList("BrandName");
		for(int i=0;i<li.size();i++)
		{
			System.out.println(li.get(i).toString());
		}
		
		
	}
	@Test
	public void jsonResponse()
	{
		String s=given().accept(ContentType.JSON).when().get("/find/127").thenReturn().asString();
		JsonPath json = new JsonPath(s);
		Assert.assertEquals(127, json.getInt("Id"));
		Assert.assertEquals("Mac Book", json.getString("LaptopName"));
		List<String> list = json.getList("Features.Feature");
		for(int i=0;i<list.size();i++)
		{
			System.out.println("-----------");
			System.out.println(list.get(i));
			System.out.println("-----------");
		}
	}
	@Test
	public void externalSource()
	{
		/*//System.setProperty("http.proxyHost", "proxytest.vcb");
		System.setProperty("http.proxyPort", "8080");
		Response response = given().accept(ContentType.JSON).when().get("http://dummy.restapiexample.com/api/v1/employees");
		List<Map<String, String>> data = response.jsonPath().getList("data");
		System.out.println(data.get(0).get("id"));*/
	}
	@Test
	public void xmlResponse()
	{
		String xmlResponse = given().accept(ContentType.XML).get("/find/127").thenReturn().asString();
		System.out.println(xmlResponse);
		given().accept(ContentType.XML).get("/find/127").then().assertThat()
		.body("Laptop.BrandName", equalTo("Apple"),"Laptop.Id",equalTo("127"))
		.and().assertThat().body("Laptop.Features.Feature",hasItem("8GB RAM"));
		XmlPath xml = new XmlPath(xmlResponse);
		Assert.assertEquals(127, xml.getInt("Laptop.Id"));
		Assert.assertEquals("Apple", xml.getString("Laptop.BrandName"));
		List<String> list = xml.getList("Laptop.Features.Feature");
		for(int i=0;i<list.size();i++)
		{
			System.out.println(list.get(i));
		}

	}
}
