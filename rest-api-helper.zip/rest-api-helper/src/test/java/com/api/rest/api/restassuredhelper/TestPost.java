package com.api.rest.api.restassuredhelper;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import java.util.ArrayList;
import java.util.Arrays;

import io.restassured.http.ContentType;

import org.apache.http.HttpStatus;
import org.junit.Ignore;
import org.junit.Test;

public class TestPost extends BaseClass {
	
	String id = (int)(1000*(Math.random())) + "";
	
	String jsonBody = "{" +
			"\"BrandName\": \"Dell\"," +
			"\"Features\": {" +
				"\"Feature\": [\"8GB RAM\"," +
				"\"1TB Hard Drive\"]"+
			"}," +
			"\"Id\": " + id + "," +
			"\"LaptopName\": \"Latitude\"" +
		"}";
	@Test @Ignore
	public void testPost()
	{
		given().
		accept(ContentType.XML).
		with().
		contentType(ContentType.JSON).
		and().body(jsonBody).
		when()
		.post("/add").
		then().assertThat().statusCode(HttpStatus.SC_OK).and().body("Laptop.Id", equalTo(id),"Laptop.BrandName",equalTo("Dell"));
	}
	@Test @Ignore
	public void testPostWithOutBody()
	{
		given()
		.accept(ContentType.XML)
		.with()
		.contentType(ContentType.JSON)
		.and()
		.when()
		.post("/add")
		.then()
		.assertThat()
		.statusCode(HttpStatus.SC_BAD_REQUEST);
		
	}
	@Test 
	public void testPostWithObjects()
	{
		String id = (int)(1000*(Math.random())) + "";
		/*Features Feat = new Features(new ArrayList<String>(Arrays.asList("8GB Ram","1 TB Hard Driver")));
		Laptopbag bag = new Laptopbag("Microsoft",id,"Windows 10",Feat);*/
		Features fet = new Features();
		Laptopbag bag = new Laptopbag();
		bag.setBrandName("Android");
		bag.setId(id);
		bag.setLaptopName("Android10");
		fet.setFeature(new ArrayList<String>(Arrays.asList("8GB RAM","1TB Hard Drive","256 HDD")));
		bag.setFeature(fet);
		given().log().all().accept(ContentType.JSON).with().contentType(ContentType.XML).and().
		body(bag).when().post("/add").then()
		.assertThat().statusCode(HttpStatus.SC_OK);
	}
	
}
