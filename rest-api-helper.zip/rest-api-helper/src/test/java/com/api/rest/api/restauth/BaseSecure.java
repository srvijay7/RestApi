package com.api.rest.api.restauth;
import static io.restassured.RestAssured.*;

import org.junit.BeforeClass;

public class BaseSecure {

	@BeforeClass
	public static void SetUp()
	{
		baseURI = "http://localhost";
		port=8080;
		basePath = "/laptop-bag/webapi/secure";
		authentication = preemptive().basic("admin", "welcome");
	}
}
