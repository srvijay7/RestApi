package com.api.rest.api.restauth;
import static io.restassured.RestAssured.*;
import io.restassured.http.ContentType;

import org.apache.http.HttpStatus;
import org.junit.Ignore;
import org.junit.Test;

public class TestGetAuth extends BaseSecure {

	@Test @Ignore
	public void testWithoutAuth()
	{
		given()
		.log()
		.all()
		.when()
		.get("http://localhost:8080/laptop-bag/webapi/secure/all")
		.then().
		assertThat()
		.statusCode(HttpStatus.SC_UNAUTHORIZED);
	}
	@Test 
	public void testWithAuth()
	{
		given()
		.log()
		.all()
		.header("Authorization","Basic YWRtaW46d2VsY29tZQ==")
		.when()
		.get("http://localhost:8080/laptop-bag/webapi/secure/all")
		.then()
		.statusCode(HttpStatus.SC_OK);
	}
	@Test 
	public void testWithBasicAuth()
	{
		String s=given()
		.log()
		.all()
		//.auth()
		//.preemptive()
		//.basic("admin", "welcome")
		.accept(ContentType.JSON)
		.when()
		.get("/all")
		.thenReturn().body().asString();
	}
}
